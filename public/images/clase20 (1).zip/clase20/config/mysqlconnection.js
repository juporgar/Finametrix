const Mysql = require('mysql');
const Conn = Mysql.createConnection(
    {
        host:'localhost',
        user:'root',
        password:'44865710',
        database:'loginExpress'
    }
)

module.exports=Conn;