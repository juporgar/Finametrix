const email= require('nodemailer');
let mailer={};
mailer.transporter = email.createTransport({
    service: 'Gmail',
    auth: {
        user: 'jaroso@gmail.com',
        pass: 'Jrodrigue1459!'
        },
    },
    {
        from:'',
            headers:{

    }

});

module.exports = mailer;