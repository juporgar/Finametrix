const Controller = require('./controller');
const UserModel = require('../models/usersModel');
const SecureService = require('../services/secureService');
class loginController extends Controller{
    constructor(req, res, next){
        super(req, res ,next);
    }

    index(){
        if(this.req.flash.error){
            this.res.render('login',{error: this.req.flash.error})
        }
        if(this.req.session.username)
        {
            this.res.render('login',{
               username: this.req.session.username
            });

        }else {
            this.res.render('login');
        }
    }

    login(){
        let userModels = new UserModel();
        let secureService = new SecureService();
        userModels.getUser(this.req.body.lg_username)
            .then((data)=>{
                if(data.length==0) {
                    this.req.flash.error="El usuario no existe";
                    this.res.redirect('/login');
                }
                if(data[0].active == 0){
                        this.req.flash.error = "La cuenta no esta activa";
                        this.res.redirect('/login');}

                if(secureService.comparePass(this.req.body.lg_password, data[0].pass))
                {
                    this.req.session.username = data[0].username;
                    this.res.render('login',{
                        username: data[0].username
                    });
                }
                else {
                    this.req.flash.error="El usuario o la contraseña es incorrecta";
                    this.res.redirect('/login');}

            })
            .catch((error)=>{
                console.log(error);
            });

        //this.res.redirect('/login');


    }
}

module.exports= loginController;