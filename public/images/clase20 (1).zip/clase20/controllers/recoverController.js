const Controller = require('./controller');
const UsersModel = require('../models/usersModel');
const IdentService = require('../services/identService');
const EmailService = require('../services/emailService');
const SecureService = require('../services/secureService');
class recoverController extends Controller
{
    constructor(req, res ,next)
    {
        super(req, res, next);
    }

    recover()
    {
        let usersModel = new UsersModel();
        let identService = new IdentService();
        usersModel.getUserByEmailOrUsername(this.req.body.email, null)
        .then((data)=>{
             data[0].hash=identService.getUUIDD(3,3);
             usersModel.setDesactivateUser(data[0])
                 .then((user)=>{
                     let emailService = new EmailService();
                     emailService.sendRecoverEmail(data[0]);
                     this.res.redirect('/login');
                 })
                 .catch(error=>{console.log(error)});
        })
        .catch(error=>console.error(error));
    }

    formActivate() {
        let userModel = new UsersModel();
        userModel.getUserByHash(this.req.params.hash)
            .then((data)=>{

                console.log(JSON.stringify(data));
                if (data.length===0){
                    this.req.flash.error="El hash no existe";
                    this.res.redirect('/recover');
                }
                else{
                    this.res.render('recoverform', {
                        title: 'Recuperar pass'
                    });
                }
            })


    };

    activate(){
        let secureService = new SecureService();
        let hash= this.req.params.hash;
        let pass = secureService.encryptPass(this.req.body.pass);
        let userModel = new UsersModel();
        userModel.setActiveRecover(hash,pass)
            .then((data)=>{
                this.res.redirect('/login');
            })

            .catch((error)=>{
                console.error(error);
            })

    }



    index()
    {

        if(this.req.flash.error){
            this.res.render('recover',{
                title:"Recuperar contraseña",
                message: this.req.flash.error
            })
        }else {
            this.res.render('recover', {
                title: "Recuperar contraseña.",
                message: null
            })
        }
    };


}

module.exports= recoverController;