const Controller = require('./controller');
const UserModel = require('../models/usersModel');
const IdentService = require('../services/identService');
const RegisterService = require('../services/secureService');
const EmailService = require('../services/emailService');
class registerController extends Controller
{
    constructor(req, res ,next){
        super(req, res, next);
    }

    index()
    {
        if(this.req.flash.error) {
            console.log(this.req.flash.error);
            this.res.render('register',{error:this.req.flash.error});
        }
        this.res.render('register');
    }

    register(registerData)
    {
        ;
        let userModel = new UserModel();
        userModel.getUserByEmailOrUsername(registerData.email, registerData.username)
            .then((data)=>{
                if(data.length===0)
                {
                    let identService = new IdentService();
                    registerData.hash = identService.getUUIDD(3,4);
                    let registerService = new RegisterService();
                    registerData.password = registerService.encryptPass(registerData.password);
                    userModel.insertUser(registerData);
                    let emailService = new EmailService();
                    emailService.sendRegisterEmail(registerData);
                }

                else this.req.flash.error="El username o el email ya esta en uso";
            })
            .catch((error)=>{
                console.log(error);
            })
        this.res.redirect('/register');
    }
}

module.exports = registerController;